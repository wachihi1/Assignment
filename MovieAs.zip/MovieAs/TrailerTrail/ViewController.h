//

//

#import "BaseViewController.h"

@interface ViewController : BaseViewController

@property(nonatomic,weak)IBOutlet UITableView *myTableView;

@property (strong, nonatomic) NSMutableArray *masterFilmList;

@end

