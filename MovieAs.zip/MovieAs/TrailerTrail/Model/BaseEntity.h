//
//  BaseEntity.h

//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>


@interface BaseEntity : NSObject

-(NSUInteger)extracIntegerValue:(NSString *)value;
-(BOOL)extractBooleanValue:(NSString *)value;

-(NSDictionary *)serialize;
-(id)getValue:(id)value;
-(void)saveLocally;

@end
