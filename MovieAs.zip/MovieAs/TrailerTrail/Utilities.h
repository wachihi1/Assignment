//
//  Utilities.h
//  7assoun
//
//

#import <Foundation/Foundation.h>

@interface Utilities : NSObject

+(NSString *)tempFilesPath;
+(NSInteger)AudioFileMaxDuration;

+(NSString *)generateUUID;

+ (NSString *)dataFilePathForFile:(NSString *)file;

+(NSString *)baseAPIUrl;
+(NSString *)baseUploadUrl;


+(void)saveSessionId:(NSString *)sessionId;
+(NSString *)sessionId;


@end
