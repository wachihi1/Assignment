
//

#import "Movie.h"


@implementation Movie

@dynamic imdbID;
@dynamic language;
@dynamic poster;
@dynamic starRating;
@dynamic title;
@dynamic type;
@dynamic year;
@dynamic runtime;
@dynamic attribute;
@dynamic genre;
@dynamic plot;
@dynamic released;

@end
