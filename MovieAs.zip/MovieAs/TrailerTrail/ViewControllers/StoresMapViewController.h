//
//  StoresMapViewController.h
//

#import "REVMapViewController.h"

@interface StoresMapViewController : REVMapViewController

@end
