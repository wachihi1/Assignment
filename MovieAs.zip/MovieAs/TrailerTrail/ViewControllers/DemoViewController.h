//
//  DemoViewController.h

//

@interface DemoViewController : UITableViewController

@property (nonatomic, strong) IBOutletCollection(UIView) NSArray *textInputs;

@end
