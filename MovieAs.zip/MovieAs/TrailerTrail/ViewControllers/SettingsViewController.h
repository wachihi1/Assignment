//
//  SettingsViewController.h
//  TrailerTrail
//
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface SettingsViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UIScrollView *myScrollView;

@end
