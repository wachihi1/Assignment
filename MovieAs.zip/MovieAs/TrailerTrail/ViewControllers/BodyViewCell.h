//
//  BodyViewCell.h
//  
//

#import <UIKit/UIKit.h>
#import "RatingView.h"

@interface BodyViewCell : UITableViewCell

@property (strong, nonatomic) UIImageView *imgTopStory;
@property (strong, nonatomic) UILabel *titleLabel, *languageLabel, *typeLabel;
@property (nonatomic, readwrite) CGFloat verticalPadding;
@property (nonatomic, strong) RatingView *starView;

@end
